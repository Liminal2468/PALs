"""File: routes.py
Description: Define versioned host API routes and session authorization.
Version: 1.0.0
"""

from __future__ import annotations

from functools import wraps
from threading import Lock
from time import monotonic
from typing import Any, Callable, TypeVar

from flask import Blueprint, current_app, g, jsonify, request, session
import requests

from api.db.db import DB
from api.limiting import limiter
from api.sessions import establish_authenticated_session


api = Blueprint("api", __name__, url_prefix="/api/v1")
F = TypeVar("F", bound=Callable[..., Any])
HEALTH_CACHE_SECONDS = 5


def _database() -> DB:
    return current_app.extensions["mentos_database"]


def _error(code: str, message: str, status: int) -> tuple[Any, int]:
    return jsonify({"error": {"code": code, "message": message}}), status


def _user_roles(database: DB, user_id: int) -> list[str]:
    assignments = database.read("user_roles", params={"user_id": user_id})
    assigned_role_ids = {row.get("role_id") for row in assignments}
    roles = database.read("roles")
    return sorted(
        row["role_key"]
        for row in roles
        if row.get("id") in assigned_role_ids and isinstance(row.get("role_key"), str)
    )


def _has_role(database: DB, user_id: int, role_key: str) -> bool:
    return role_key in _user_roles(database, user_id)


def _serialize_record(record: Any, allowed_fields: tuple[str, ...]) -> dict[str, Any]:
    if not isinstance(record, dict):
        raise RuntimeError("Database returned an invalid record.")
    return {field: record[field] for field in allowed_fields if field in record}


def _serialize_learning_requests(rows: Any) -> list[dict[str, Any]]:
    if not isinstance(rows, list):
        raise RuntimeError("Database returned an invalid learning-request list.")
    fields = (
        "id",
        "subject_id",
        "topic_id",
        "current_proficiency",
        "requested_help",
        "preferred_format",
        "request_status",
        "created_at",
        "updated_at",
    )
    return [_serialize_record(row, fields) for row in rows]


def authenticated(handler: F) -> F:
    @wraps(handler)
    def wrapped(*args: Any, **kwargs: Any) -> Any:
        # Routes trust only the server-side session identity, never a body ID.
        user_id = session.get("user_id")
        if not user_id:
            return _error("unauthorized", "Authentication is required.", 401)
        user = _database().read("users", user_id)
        if not isinstance(user, dict):
            session.clear()
            return _error("unauthorized", "Authentication is required.", 401)
        if user.get("account_status") != "active":
            session.clear()
            return _error("account_inactive", "The account is not active.", 403)
        g.authenticated_user = user
        return handler(*args, **kwargs)

    return wrapped  # type: ignore[return-value]


@api.get("/health")
def health() -> Any:
    app = current_app
    cache = app.extensions["dbserv_health_cache"]
    with app.extensions["dbserv_health_lock"]:
        now = monotonic()
        if cache["expires_at"] > now:
            return jsonify({"status": cache["status"]})

        try:
            _database().check_database_health()
        except (requests.RequestException, RuntimeError):
            app.logger.exception("DBSERV readiness check failed.")
            cache["status"] = "degraded"
        else:
            cache["status"] = "ready"
        cache["expires_at"] = now + HEALTH_CACHE_SECONDS
        return jsonify({"status": cache["status"]})


@api.route("/session", methods=["GET", "DELETE"])
@limiter.limit("30 per 15 minutes", override_defaults=True)
def session_status() -> Any:
    if request.method == "DELETE":
        session.clear()
        return "", 204
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"authenticated": False})
    return jsonify({
        "authenticated": True,
        "user_id": user_id,
        "authenticated_at": session.get("authenticated_at"),
    })


@api.post("/auth/login")
@limiter.limit("10 per 15 minutes", override_defaults=True)
def login_not_configured() -> Any:
    # TODO: Replace this placeholder only after the eLMS verification flow is approved.
    return _error(
        "not_implemented",
        "eLMS authentication has not been configured.",
        501,
    )


@api.get("/me")
@authenticated
def get_me() -> Any:
    database = _database()
    user_id = session["user_id"]
    profile_rows = database.read("student_profiles", params={"user_id": user_id})
    if not isinstance(profile_rows, list):
        raise RuntimeError("Database returned an invalid student-profile list.")
    return jsonify({
        "data": {
            "user": _serialize_record(g.authenticated_user, ("id", "display_name")),
            "student_profile": (
                _serialize_record(
                    profile_rows[0],
                    ("grade_level", "strand", "timezone", "learning_preferences"),
                )
                if profile_rows
                else None
            ),
            "roles": _user_roles(database, user_id),
        },
    })


@api.patch("/me")
@authenticated
def update_me() -> Any:
    payload = request.get_json(silent=False)
    if not isinstance(payload, dict) or not payload:
        return _error("bad_request", "Expected a non-empty JSON object.", 400)
    allowed = {"display_name", "grade_level", "strand", "timezone", "learning_preferences"}
    # Reject identity, role, and account-status fields rather than silently ignoring them.
    unknown = set(payload) - allowed
    if unknown:
        return _error(
            "bad_request",
            f"Unsupported profile field(s): {', '.join(sorted(unknown))}.",
            400,
        )
    if "display_name" in payload and (
        not isinstance(payload["display_name"], str)
        or not payload["display_name"].strip()
        or len(payload["display_name"]) > 120
    ):
        return _error("bad_request", "display_name must be 1 to 120 characters.", 400)
    if "grade_level" in payload and (
        isinstance(payload["grade_level"], bool)
        or payload["grade_level"] not in {11, 12}
    ):
        return _error("bad_request", "grade_level must be 11 or 12.", 400)
    for field in ("strand", "timezone"):
        if field in payload and (
            not isinstance(payload[field], str)
            or not payload[field].strip()
            or len(payload[field]) > (100 if field == "strand" else 64)
        ):
            return _error("bad_request", f"{field} must be a non-empty string.", 400)
    if "learning_preferences" in payload and not isinstance(
        payload["learning_preferences"], (dict, list)
    ):
        return _error("bad_request", "learning_preferences must be an object or array.", 400)

    database = _database()
    user_id = session["user_id"]
    user_changes = {key: payload[key] for key in ("display_name",) if key in payload}
    profile_changes = {
        key: value
        for key, value in payload.items()
        if key in {"grade_level", "strand", "timezone", "learning_preferences"}
    }

    profile_rows = (
        database.read("student_profiles", params={"user_id": user_id})
        if profile_changes
        else []
    )
    if profile_changes and not profile_rows:
        return _error("conflict", "Student profile has not been created.", 409)

    if user_changes:
        database.update("users", user_id, user_changes)
    if profile_changes:
        database.update("student_profiles", profile_rows[0]["id"], profile_changes)
    return get_me()


@api.get("/learning-requests")
@authenticated
def list_learning_requests() -> Any:
    rows = _database().read(
        "learning_requests",
        params={"tutee_user_id": session["user_id"]},
    )
    return jsonify({"data": _serialize_learning_requests(rows)})


@api.post("/learning-requests")
@authenticated
def create_learning_request() -> Any:
    payload = request.get_json(silent=False)
    if not isinstance(payload, dict):
        return _error("bad_request", "Expected a JSON object.", 400)

    allowed = {
        "subject_id",
        "topic_id",
        "current_proficiency",
        "requested_help",
        "preferred_format",
    }
    if set(payload) - allowed or "subject_id" not in payload:
        return _error("bad_request", "Invalid learning-request fields.", 400)
    proficiency = payload.get("current_proficiency")
    if proficiency is not None and (
        isinstance(proficiency, bool)
        or not isinstance(proficiency, int)
        or proficiency < 1
        or proficiency > 5
    ):
        return _error("bad_request", "current_proficiency must be an integer from 1 to 5.", 400)
    preferred_format = payload.get("preferred_format", "either")
    if preferred_format not in {"one_to_one", "group", "either"}:
        return _error("bad_request", "Invalid preferred_format.", 400)
    subject_id = payload["subject_id"]
    if isinstance(subject_id, bool) or not isinstance(subject_id, int) or subject_id < 1:
        return _error("bad_request", "subject_id must be a positive integer.", 400)
    topic_id = payload.get("topic_id")
    if topic_id is not None and (
        isinstance(topic_id, bool) or not isinstance(topic_id, int) or topic_id < 1
    ):
        return _error("bad_request", "topic_id must be a positive integer.", 400)
    requested_help = payload.get("requested_help")
    if requested_help is not None and (
        not isinstance(requested_help, str) or len(requested_help) > 4000
    ):
        return _error("bad_request", "requested_help must be a string up to 4000 characters.", 400)
    if not _has_role(_database(), session["user_id"], "tutee"):
        return _error("forbidden", "The authenticated user does not have the tutee role.", 403)

    # Derive ownership from the authenticated session to prevent user-ID spoofing.
    created = _database().create(
        "learning_requests",
        {
            **payload,
            "tutee_user_id": session["user_id"],
            "preferred_format": preferred_format,
            "request_status": "open",
        },
    )
    return jsonify({"data": _serialize_record(created, ("id",))}), 201


def establish_user_session(user_id: int | str) -> None:
    establish_authenticated_session(user_id)
