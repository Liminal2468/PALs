from __future__ import annotations

import hashlib
import os
import time
import unittest
from datetime import datetime, timedelta, timezone
from typing import Any
from unittest.mock import patch

import requests
from flask import Flask
from werkzeug.middleware.proxy_fix import ProxyFix

from api.app import create_app, main
from api.routes import HEALTH_CACHE_SECONDS


class MemoryDatabase:
    def __init__(self) -> None:
        self.rows: dict[str, list[dict[str, Any]]] = {
            "web_sessions": [],
            "users": [{
                "id": 7,
                "display_name": "Kai",
                "email": "private@example.test",
                "external_subject": "private-subject",
                "account_status": "active",
            }],
            "student_profiles": [{
                "id": 12,
                "user_id": 7,
                "grade_level": 12,
                "strand": "IT",
                "timezone": "Asia/Manila",
                "learning_preferences": {"format": "visual"},
                "private_note": "do not expose",
            }],
            "roles": [{"id": 1, "role_key": "tutee"}],
            "user_roles": [{"id": 2, "user_id": 7, "role_id": 1}],
            "learning_requests": [],
        }
        self.next_id = 100
        self.health_checks = 0
        self.health_error: Exception | None = None
        self.read_errors: dict[str, Exception] = {}

    def check_database_health(self) -> None:
        self.health_checks += 1
        if self.health_error is not None:
            raise self.health_error

    def read(
        self,
        resource: str,
        record_id: str | int | None = None,
        *,
        params: dict[str, Any] | None = None,
    ) -> Any:
        if resource in self.read_errors:
            raise self.read_errors[resource]
        if record_id is not None:
            return next(
                (dict(row) for row in self.rows.get(resource, []) if row["id"] == int(record_id)),
                None,
            )
        return [
            dict(row)
            for row in self.rows.get(resource, [])
            if all(row.get(key) == value for key, value in (params or {}).items())
        ]

    def create(self, resource: str, data: dict[str, Any]) -> dict[str, Any]:
        row = {"id": self.next_id, **data}
        self.next_id += 1
        self.rows.setdefault(resource, []).append(row)
        return {"id": row["id"], "affected_rows": 1}

    def update(self, resource: str, record_id: str | int, data: dict[str, Any]) -> None:
        for row in self.rows.get(resource, []):
            if row["id"] == int(record_id):
                row.update(data)
                return
        raise AssertionError("Record not found")

    def delete(self, resource: str, record_id: str | int) -> None:
        self.rows[resource] = [
            row for row in self.rows.get(resource, []) if row["id"] != int(record_id)
        ]


class HostApiTests(unittest.TestCase):
    def setUp(self) -> None:
        self.database = MemoryDatabase()
        self.app = create_app(self.database, testing=True)
        self.client = self.app.test_client()
        self.app.config["SESSION_COOKIE_SECURE"] = False

    def authenticate(self) -> None:
        with self.client.session_transaction() as browser_session:
            browser_session.update({"user_id": 7, "authenticated_at": "test"})

    def test_health_and_login_placeholder(self) -> None:
        response = self.client.get("/api/v1/health")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json, {"status": "ready"})
        self.assertNotIn("Cookie", response.vary)
        self.assertEqual(self.database.health_checks, 1)

        cached = self.client.get("/api/v1/health")
        self.assertEqual(cached.json, {"status": "ready"})
        self.assertEqual(self.database.health_checks, 1)

        login = self.client.post("/api/v1/auth/login", json={})
        self.assertEqual(login.status_code, 501)
        self.assertEqual(login.headers["Cache-Control"], "no-store")
        self.assertEqual(login.headers["X-Content-Type-Options"], "nosniff")

    def test_health_hides_dbserv_failure_details_and_caches_degraded_state(self) -> None:
        self.database.health_error = RuntimeError("private upstream detail")

        with self.assertLogs("api", level="ERROR"):
            response = self.client.get("/api/v1/health")
        self.assertEqual(response.json, {"status": "degraded"})
        self.assertNotIn("private upstream detail", response.get_data(as_text=True))

        cached = self.client.get("/api/v1/health")
        self.assertEqual(cached.json, {"status": "degraded"})
        self.assertEqual(self.database.health_checks, 1)

        self.app.extensions["dbserv_health_cache"]["expires_at"] = 0
        with patch("api.routes.monotonic", return_value=HEALTH_CACHE_SECONDS + 1):
            with self.assertLogs("api", level="ERROR"):
                refreshed = self.client.get("/api/v1/health")
        self.assertEqual(refreshed.json, {"status": "degraded"})
        self.assertEqual(self.database.health_checks, 2)

    def test_profile_and_learning_request_require_session(self) -> None:
        unauthenticated = self.client.get("/api/v1/me")
        self.assertEqual(unauthenticated.status_code, 401)
        self.assertIn("Cookie", unauthenticated.vary)
        self.authenticate()

        profile = self.client.get("/api/v1/me")
        self.assertEqual(profile.status_code, 200)
        self.assertIn("Cookie", profile.vary)
        self.assertEqual(profile.json["data"]["user"]["id"], 7)
        self.assertEqual(
            set(profile.json["data"]["user"]),
            {"id", "display_name"},
        )
        self.assertNotIn("email", profile.json["data"]["user"])
        self.assertNotIn("external_subject", profile.json["data"]["user"])
        self.assertEqual(profile.json["data"]["roles"], ["tutee"])
        self.assertEqual(
            profile.json["data"]["student_profile"]["strand"],
            "IT",
        )
        self.assertEqual(
            set(profile.json["data"]["student_profile"]),
            {"grade_level", "strand", "timezone", "learning_preferences"},
        )

        created = self.client.post(
            "/api/v1/learning-requests",
            json={
                "subject_id": 3,
                "current_proficiency": 2,
                "preferred_format": "one_to_one",
            },
        )
        self.assertEqual(created.status_code, 201)
        stored = self.database.rows["learning_requests"][0]
        self.assertEqual(stored["tutee_user_id"], 7)
        self.assertEqual(stored["request_status"], "open")

        listed = self.client.get("/api/v1/learning-requests")
        self.assertEqual(len(listed.json["data"]), 1)
        self.assertEqual(
            set(listed.json["data"][0]),
            {
                "id",
                "subject_id",
                "current_proficiency",
                "preferred_format",
                "request_status",
            },
        )

    def test_inactive_account_cannot_use_authenticated_routes(self) -> None:
        self.authenticate()
        self.database.rows["users"][0]["account_status"] = "suspended"

        response = self.client.get("/api/v1/me")

        self.assertEqual(response.status_code, 403)
        self.assertEqual(response.json["error"]["code"], "account_inactive")
        self.assertFalse(self.client.get("/api/v1/session").json["authenticated"])

    def test_learning_request_serializer_excludes_unapproved_fields(self) -> None:
        self.authenticate()
        self.database.rows["learning_requests"] = [{
            "id": 23,
            "tutee_user_id": 7,
            "subject_id": 3,
            "topic_id": 4,
            "current_proficiency": 2,
            "requested_help": "Review examples",
            "preferred_format": "one_to_one",
            "request_status": "open",
            "created_at": "2026-11-02T10:00:00Z",
            "updated_at": "2026-11-02T10:00:00Z",
            "private_note": "do not expose",
            "email": "private@example.test",
        }]

        response = self.client.get("/api/v1/learning-requests")

        self.assertEqual(
            set(response.json["data"][0]),
            {
                "id",
                "subject_id",
                "topic_id",
                "current_proficiency",
                "requested_help",
                "preferred_format",
                "request_status",
                "created_at",
                "updated_at",
            },
        )
        self.assertNotIn("email", response.json["data"][0])

    def test_profile_rejects_role_escalation_fields(self) -> None:
        self.authenticate()
        response = self.client.patch("/api/v1/me", json={"account_status": "admin"})
        self.assertEqual(response.status_code, 400)

    def test_session_cookie_is_opaque_and_http_only(self) -> None:
        self.assertEqual(self.app.config["SESSION_COOKIE_NAME"], "mentos_session")
        with self.client.session_transaction() as browser_session:
            browser_session["user_id"] = 7
        cookie = self.client.get_cookie("mentos_session")
        self.assertIsNotNone(cookie)
        self.assertTrue(cookie.http_only)
        self.assertNotIn("user_id", cookie.value)
        self.assertEqual(len(self.database.rows["web_sessions"]), 1)
        self.assertNotEqual(
            self.database.rows["web_sessions"][0]["session_key"],
            cookie.value,
        )
        self.assertEqual(
            self.database.rows["web_sessions"][0]["session_key"],
            hashlib.sha256(cookie.value.encode("utf-8")).hexdigest(),
        )

    def test_expiration_uses_utc_when_local_timezone_is_not_utc(self) -> None:
        original_tz = os.environ.get("TZ")
        os.environ["TZ"] = "America/Los_Angeles"
        time.tzset()
        self.addCleanup(self._restore_timezone, original_tz)

        raw_session_id = "legacy-session-key"
        expires_at = datetime.now(timezone.utc) + timedelta(hours=1)
        self.database.rows["web_sessions"].append({
            "id": 41,
            "session_key": raw_session_id,
            "session_data": {"user_id": 7, "authenticated_at": "test"},
            "expires_at": expires_at.replace(tzinfo=None).isoformat(sep=" "),
        })
        self.client.set_cookie("mentos_session", raw_session_id)

        active = self.client.get("/api/v1/session")

        self.assertTrue(active.json["authenticated"])
        self.assertEqual(
            self.database.rows["web_sessions"][0]["session_key"],
            hashlib.sha256(raw_session_id.encode("utf-8")).hexdigest(),
        )

        self.database.rows["web_sessions"][0]["expires_at"] = (
            datetime.now(timezone.utc) - timedelta(hours=1)
        ).replace(tzinfo=None).isoformat(sep=" ")
        expired = self.client.get("/api/v1/session")

        self.assertFalse(expired.json["authenticated"])
        self.assertEqual(self.database.rows["web_sessions"], [])

    @staticmethod
    def _restore_timezone(original_tz: str | None) -> None:
        if original_tz is None:
            os.environ.pop("TZ", None)
        else:
            os.environ["TZ"] = original_tz
        time.tzset()

    def test_deleting_session_revokes_server_side_record(self) -> None:
        self.authenticate()
        self.assertEqual(len(self.database.rows["web_sessions"]), 1)

        response = self.client.delete("/api/v1/session")

        self.assertEqual(response.status_code, 204)
        self.assertEqual(self.database.rows["web_sessions"], [])
        self.assertFalse(self.client.get("/api/v1/session").json["authenticated"])

    def test_upstream_errors_are_logged_and_return_stable_sanitized_errors(self) -> None:
        self.authenticate()
        upstream_429 = requests.Response()
        upstream_429.status_code = 429
        upstream_500 = requests.Response()
        upstream_500.status_code = 500
        cases = (
            (requests.Timeout("private upstream detail"), 503, "dbserv_timeout"),
            (requests.ConnectionError("private upstream detail"), 503, "dbserv_unavailable"),
            (
                requests.HTTPError("private upstream detail", response=upstream_429),
                503,
                "dbserv_rate_limited",
            ),
            (
                requests.HTTPError("private upstream detail", response=upstream_500),
                502,
                "dbserv_error",
            ),
        )

        for error, status, code in cases:
            with self.subTest(code=code):
                self.database.read_errors["student_profiles"] = error
                with self.assertLogs("api.app", level="ERROR") as captured:
                    response = self.client.get("/api/v1/me")
                self.database.read_errors.clear()

                self.assertEqual(response.status_code, status)
                self.assertEqual(response.json["error"]["code"], code)
                self.assertNotIn("private upstream detail", response.get_data(as_text=True))
                self.assertIn("private upstream detail", "\n".join(captured.output))
                self.assertEqual(response.headers["Cache-Control"], "no-store")
                self.assertEqual(response.headers["X-Content-Type-Options"], "nosniff")

    def test_rate_limits_cover_api_and_tighten_session_and_login_routes(self) -> None:
        api_ip = "192.0.2.110"
        for _ in range(120):
            response = self.client.get(
                "/api/v1/health",
                environ_overrides={"REMOTE_ADDR": api_ip},
            )
            self.assertEqual(response.status_code, 200)

        limited = self.client.get(
            "/api/v1/health",
            environ_overrides={"REMOTE_ADDR": api_ip},
        )
        self.assertEqual(limited.status_code, 429)
        self.assertEqual(limited.json["error"]["code"], "rate_limited")
        self.assertEqual(limited.headers["Cache-Control"], "no-store")
        self.assertEqual(limited.headers["X-Content-Type-Options"], "nosniff")
        self.assertEqual(
            self.client.get(
                "/api/v1/health",
                environ_overrides={"REMOTE_ADDR": "192.0.2.111"},
            ).status_code,
            200,
        )

        session_ip = "192.0.2.112"
        for _ in range(30):
            self.assertEqual(
                self.client.get(
                    "/api/v1/session",
                    environ_overrides={"REMOTE_ADDR": session_ip},
                ).status_code,
                200,
            )
        self.assertEqual(
            self.client.get(
                "/api/v1/session",
                environ_overrides={"REMOTE_ADDR": session_ip},
            ).status_code,
            429,
        )

        login_ip = "192.0.2.113"
        for _ in range(10):
            self.assertEqual(
                self.client.post(
                    "/api/v1/auth/login",
                    environ_overrides={"REMOTE_ADDR": login_ip},
                ).status_code,
                501,
            )
        self.assertEqual(
            self.client.post(
                "/api/v1/auth/login",
                environ_overrides={"REMOTE_ADDR": login_ip},
            ).status_code,
            429,
        )

    def test_proxy_fix_is_explicit_and_rate_limit_uses_trusted_forwarded_ip(self) -> None:
        with patch.dict(os.environ, {"TRUST_PROXY": "false"}):
            default_app = create_app(MemoryDatabase(), testing=True)
        self.assertNotIsInstance(default_app.wsgi_app, ProxyFix)

        with patch.dict(os.environ, {"TRUST_PROXY": "true"}):
            proxied_app = create_app(MemoryDatabase(), testing=True)
        self.assertIsInstance(proxied_app.wsgi_app, ProxyFix)
        client = proxied_app.test_client()
        remote_addr = "127.0.0.1"
        first_ip_headers = {"X-Forwarded-For": "198.51.100.40"}
        for _ in range(120):
            self.assertEqual(
                client.get(
                    "/api/v1/health",
                    headers=first_ip_headers,
                    environ_overrides={"REMOTE_ADDR": remote_addr},
                ).status_code,
                200,
            )
        self.assertEqual(
            client.get(
                "/api/v1/health",
                headers={"X-Forwarded-For": "198.51.100.41"},
                environ_overrides={"REMOTE_ADDR": remote_addr},
            ).status_code,
            200,
        )

    def test_main_runs_waitress_on_loopback(self) -> None:
        with (
            patch.dict(os.environ, {"PORT": "8123", "TRUST_PROXY": "false"}),
            patch("api.app.serve") as waitress_serve,
        ):
            main()

        served_app = waitress_serve.call_args.args[0]
        self.assertIsInstance(served_app, Flask)
        self.assertEqual(waitress_serve.call_args.kwargs, {"host": "127.0.0.1", "port": 8123})


if __name__ == "__main__":
    unittest.main()
