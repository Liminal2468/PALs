server side REST API:

- Database API - Endpoint: `/db` - in server/database
- Profile API - Endpoint: `/acc` - in server/accounts
- Scheduling API - Enpoint: `/sched` - in server/scheduler
- Feedback API - Endpoint: `/fb` - in server/feedback
- Analytics API - Endpoint: `/adata` - in server/analyst


- Messaging API (Last keep this at the end, this is a pretty big API) - endpoint: `/chat/v1` - in server/chat
- Authentication API (Just make the skelleton for now there isn't a straight plan for the login flow yet) - endpoints: `/auth/v1` 