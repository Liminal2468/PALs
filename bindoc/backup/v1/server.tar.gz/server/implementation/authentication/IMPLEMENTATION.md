# Discussed
The team suggest a mass implementation due to the time restraint. The following are to be followed by an agent or a developer, as guide or guardrails.
- TODO: Implement a provider route rather than a traditional login page, we will be using a provider based.
    - FLOW: LOGIN PAGE -> MENU COMPONENT POP UP (modal) -> OPTIONS: (LOGIN WITH {PROVIDER} | {ADMIN LOGIN FLOW})
        - IF PROVIDER -> TRACK/LOG ELSE REGISTER IF NO ACCOUNT FOUND -> LOOP TO SIGNUP PROVIDER WISE
        - IF ADMIN -> REDIRECT TO ADMIN LOGIN PAGE (Classic text login. note tag: #100) -> IF AUTH YES (SEND ACCOUNT CHECK) ELSE REJECT AND LOG ATTEPT

NOTES:
- #100 - The inputs through these should be sanitized to prevent any injectioning.
