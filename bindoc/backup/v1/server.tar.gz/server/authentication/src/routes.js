import { Router } from "express";

export const router = Router();

router.get("/health", (_req, res) => {
  res.json({ service: "authentication", status: "skeleton" });
});

router.use((_req, res) => {
  res.status(501).json({
    error: { code: "not_implemented", message: "Authentication flow is not defined yet." },
  });
});
