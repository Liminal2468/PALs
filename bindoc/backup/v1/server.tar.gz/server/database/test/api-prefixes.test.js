import assert from "node:assert/strict";
import test from "node:test";
import { app } from "../../src/app.js";

test("mounts each API under its assigned prefix", async (t) => {
  const server = app.listen(0);
  t.after(() => new Promise((resolve, reject) => {
    server.close((error) => error ? reject(error) : resolve());
  }));
  await new Promise((resolve) => server.once("listening", resolve));
  const baseUrl = `http://127.0.0.1:${server.address().port}`;

  const databaseHealth = await fetch(`${baseUrl}/db/health`);
  assert.equal(databaseHealth.status, 200);
  assert.deepEqual(await databaseHealth.json(), { service: "database", status: "alive" });

  const databaseReadiness = await fetch(`${baseUrl}/db/health/database`);
  assert.equal(databaseReadiness.status, 401);

  const services = [
    ["/acc/health", "accounts"],
    ["/sched/health", "scheduler"],
    ["/fb/health", "feedback"],
    ["/adata/health", "analyst"],
    ["/connect/health", "connect"],
    ["/auth/v1/health", "authentication"],
    ["/chat/v1/health", "chat"],
  ];

  for (const [path, service] of services) {
    const response = await fetch(`${baseUrl}${path}`);
    assert.equal(response.status, 200, path);
    const expected = {
      service,
      status: ["authentication", "chat"].includes(service) ? "skeleton" : "ready",
    };
    if (service === "connect") {
      expected.algorithm = "weighted-baseline-v1-draft";
    }
    assert.deepEqual(await response.json(), expected);
  }

  const notImplemented = await fetch(`${baseUrl}/acc/profile`);
  assert.equal(notImplemented.status, 501);
  assert.equal((await notImplemented.json()).error.code, "not_implemented");

  const oldDatabasePrefix = await fetch(`${baseUrl}/api/students`);
  assert.equal(oldDatabasePrefix.status, 404);
});
