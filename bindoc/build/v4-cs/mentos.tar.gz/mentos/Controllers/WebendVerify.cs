using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Mentos.Host.Webend;

namespace Mentos.Host.Controllers;

[Controller]
[ApiController]
[Route("api/v1")]
public sealed class WebendVerify : WebendController
{
    public WebendVerify(HostDbservClient dbserv) : base(dbserv) { }

    [HttpGet("verify")]
    public async Task<IActionResult> Verify([FromQuery] string? code, CancellationToken cancellationToken)
    {
        var normalized = code?.Trim();
        if (normalized is null || normalized.Length != 6 || !normalized.All(char.IsDigit))
            return BadRequest(new { error = new { code = "invalid_verification_code", message = "Verification code must contain exactly six digits." } });

        var response = await dbserv.SendAsync(
            HttpMethod.Get,
            $"/verify?code={Uri.EscapeDataString(normalized)}",
            "",
            null,
            cancellationToken);
        return DbservResponse(response);
    }
}
